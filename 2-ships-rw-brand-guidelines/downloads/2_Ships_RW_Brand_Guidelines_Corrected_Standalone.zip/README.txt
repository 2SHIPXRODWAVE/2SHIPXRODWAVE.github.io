2 SHIPS RW LLC — CORRECTED STANDALONE BRAND GUIDELINES

Open:
2_Ships_RW_Brand_Guidelines_Corrected.html

Corrections included:
- Exact legal name preserved: 2 Ships RW LLC
- Official brand promise added: Rare Finds. Real Value. Veteran-Owned.
- Corrected detailed red and warm-white logo masters included
- True simplified micro mark added for 48–96 px applications
- Detailed emblem rule updated to 128 px or larger
- Web hero and back cover updated with the official brand promise
- Unresolved template variables replaced with Space Grotesk and IBM Plex Sans
- Missing runtime dependencies removed so the file opens as a standalone scrolling HTML deck
- All required image assets included in the assets folder

The broader business-growth and execution positioning from the supplied guide remains intact. “Build the Next Move” remains available as a campaign/consulting headline, while “Rare Finds. Real Value. Veteran-Owned.” is treated as the official brand promise.
