2 SHIPS RW LLC — CORRECTED LOGO PACKAGE
Prepared July 29, 2026

OFFICIAL LEGAL NAME
2 Ships RW LLC

OFFICIAL BRAND PROMISE
Rare Finds. Real Value. Veteran-Owned.

SIGNATURE COLORWAY
Signal Red #C1121F on Command Black #08090B
Warm White #F2EFE9 is used for the company name and tagline.

FILES AND USES

1. 2_Ships_RW_Horizontal_Lockup_Black.png
   High-resolution primary horizontal logo for dark website headers, signs, banners, and presentations.

2. 2_Ships_RW_Horizontal_Lockup_Transparent.png
   Transparent horizontal lockup for professional layout and print use. Verify contrast before placing it over photographs.

3. 2_Ships_RW_Horizontal_Lockup_Web_2400.png
   Web-ready 2400-pixel-wide black-background version.

4. 2_Ships_RW_True_Micro_Mark_Transparent_2048.png
   Simplified transparent emblem for icons, labels, embroidery preparation, and small applications.

5. 2_Ships_RW_True_Micro_Mark_Black_2048.png
   Simplified emblem on the official black background.

6. 2_Ships_RW_Micro_Icon_[SIZE]px_Black.png
   Ready-to-use social/avatar/favicon versions at 32, 48, 64, 128, 256, and 512 pixels.

7. 2_Ships_RW_Micro_Icon_[SIZE]px_Transparent.png
   Transparent versions at the same sizes.

8. 2_Ships_RW_Official_Detailed_Red_Transparent.png
   Original detailed red emblem extracted from the supplied brand guide. Use at larger sizes.

9. 2_Ships_RW_Official_Detailed_White_Transparent.png
   Original detailed warm-white emblem for dark backgrounds.

SIZE RULE
Use the true micro mark below 128 pixels. Use the detailed emblem at 128 pixels or larger when the production method can preserve its linework.

DO NOT
Do not change the legal name, distort the emblem, recolor it outside the approved palette, add flags or camouflage, place it over a busy background, or replace the official brand promise without owner approval.
